package com.example.moviesdekho;

public class Config {
    public static String PACKAGE_NAME = "app.movie.tutorial.com";
    public final static String IMAGE_URL_BASE_PATH = "http://image.tmdb.org/t/p/w342//";
    public static final String API_BASE_URL = "http://api.themoviedb.org/3/";
    public final static String API_KEY = "8c2cca40d0d357c045dd2a2f44fe587a";
}
