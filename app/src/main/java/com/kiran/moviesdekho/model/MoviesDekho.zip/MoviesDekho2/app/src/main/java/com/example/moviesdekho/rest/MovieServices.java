package com.example.moviesdekho.rest;

import com.example.moviesdekho.model.movies.MovieResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface MovieServices {
    @GET("movie/top_rated")
    Call<MovieResponse> getTopRatedMovies(@Query("api_key") String apikey);

    //MOVIE DETAIL
    @GET("/3/movie/{id}")
    Call<com.example.moviesdekho.model.Movie.MovieResponse> movieDetails(@Path("id") int movieID, @Query("api_key") String apiKey);
}
